BiReN v1.1 — Stock P&L & Budget Manager\n\nCrash-safe Android build. v1.1 adds defensive startup/local-data recovery so malformed saved data cannot prevent the launcher screen from opening.\n\n# BiReN Stock P&L Manager

A simple Android stock P&L and three-category budget manager with the final BiReN Taurus green-and-gold branding.

## Core flow

**Trade → Profit/Loss → Automatic % Allocation → Budget IN/OUT → Remaining Balance → Carry Forward → Reports**

## Included

- Buy/Sell trade entry
- FIFO realized P&L calculation
- Editable Personal/Savings/Reinvestment category names
- Editable allocation percentages; total must equal 100%
- Automatic profit allocation based on current percentages
- Budget IN and OUT entries
- Cumulative ledger balance and carry-forward behavior
- Edit/save/delete for trades and budget entries
- Built-in quick calculator for amount/price fields
- Lifetime, monthly, yearly and custom P&L report views
- Final BiReN Taurus green-and-gold logo
- GitHub Actions workflow

## GitHub: upload the ZIP itself

GitHub does not execute workflows that are hidden inside an uploaded ZIP. If you want to keep the Android project as a ZIP file in the repository, add the separate workflow file `build-from-uploaded-zip.yml` to `.github/workflows/` **once**. That workflow extracts the ZIP automatically and builds the APK.

Repository layout:

```text
SM/
├── BiReN-Stock-PnL-Android-Final.zip
└── .github/
    └── workflows/
        └── build-from-uploaded-zip.yml
```

## Android Studio

If you extract the ZIP, open the folder containing `settings.gradle.kts` in Android Studio and run the app.

## Build

The GitHub workflow uses Java 17, Android SDK 35 and Gradle 8.11, then uploads the debug APK as an Actions artifact.

## Note

This is a compact offline-first implementation. A production release can later move the in-memory/persisted JSON ledger to Room without changing the core UI flow.
