package com.biren.stockpnl

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

private const val GREEN = 0xFF0B3D2E.toInt()
private const val GOLD = 0xFFD4A62A.toInt()
private const val CREAM = 0xFFFFF8E7.toInt()
private const val RED = 0xFFB3261E.toInt()

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("biren", MODE_PRIVATE) }
    private var trades = mutableListOf<Trade>()
    private var categories = mutableListOf<Category>()
    private var entries = mutableListOf<BudgetEntry>()
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep launcher startup deliberately small and defensive. A bad/corrupt
        // preference value must never prevent the app from opening.
        try {
            loadData()
            if (categories.isEmpty()) {
                categories.addAll(
                    listOf(
                        Category("Personal", 40.0),
                        Category("Savings", 30.0),
                        Category("Reinvestment", 30.0)
                    )
                )
            }
            saveData()
        } catch (_: Exception) {
            // Recover from malformed legacy/corrupt local data.
            prefs.edit().clear().apply()
            trades.clear()
            entries.clear()
            categories.clear()
            categories.addAll(
                listOf(
                    Category("Personal", 40.0),
                    Category("Savings", 30.0),
                    Category("Reinvestment", 30.0)
                )
            )
            try { saveData() } catch (_: Exception) { }
        }
        try {
            showHome()
        } catch (_: Exception) {
            // Last-resort safe landing screen instead of a launch crash.
            val fallback = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(32, 32, 32, 32)
            }
            fallback.addView(TextView(this).apply {
                text = "BiReN"
                textSize = 32f
                setTextColor(GREEN)
                gravity = Gravity.CENTER
            })
            fallback.addView(TextView(this).apply {
                text = "Ready. Your local data is safe."
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(0, 16, 0, 16)
            })
            fallback.addView(Button(this).apply {
                text = "Open Home"
                setOnClickListener { try { showHome() } catch (_: Exception) { } }
            })
            setContentView(fallback)
        }
    }

    data class Trade(var id:String=UUID.randomUUID().toString(), var type:String, var stock:String, var qty:Double, var price:Double, var date:String, var charges:Double)
    data class Category(var name:String, var percent:Double)
    data class BudgetEntry(var id:String=UUID.randomUUID().toString(), var category:String, var type:String, var amount:Double, var description:String, var date:String)

    private fun loadData() {
        trades.clear()
        categories.clear()
        entries.clear()

        try {
            val t = JSONArray(prefs.getString("trades", "[]") ?: "[]")
            for (i in 0 until t.length()) {
                val o = t.getJSONObject(i)
                trades.add(
                    Trade(
                        o.getString("id"),
                        o.getString("type"),
                        o.getString("stock"),
                        o.getDouble("qty"),
                        o.getDouble("price"),
                        o.getString("date"),
                        o.optDouble("charges", 0.0)
                    )
                )
            }
        } catch (_: Exception) {
            trades.clear()
        }

        try {
            val c = JSONArray(prefs.getString("categories", "[]") ?: "[]")
            for (i in 0 until c.length()) {
                val o = c.getJSONObject(i)
                categories.add(
                    Category(
                        o.getString("name"),
                        o.getDouble("percent")
                    )
                )
            }
        } catch (_: Exception) {
            categories.clear()
        }

        try {
            val e = JSONArray(prefs.getString("entries", "[]") ?: "[]")
            for (i in 0 until e.length()) {
                val o = e.getJSONObject(i)
                entries.add(
                    BudgetEntry(
                        o.getString("id"),
                        o.getString("category"),
                        o.getString("type"),
                        o.getDouble("amount"),
                        o.optString("description", ""),
                        o.getString("date")
                    )
                )
            }
        } catch (_: Exception) {
            entries.clear()
        }
    }

    private fun saveData() {
        val t=JSONArray(); trades.forEach{t.put(JSONObject().apply{put("id",it.id);put("type",it.type);put("stock",it.stock);put("qty",it.qty);put("price",it.price);put("date",it.date);put("charges",it.charges)})}
        val c=JSONArray(); categories.forEach{c.put(JSONObject().apply{put("name",it.name);put("percent",it.percent)})}
        val e=JSONArray(); entries.forEach{e.put(JSONObject().apply{put("id",it.id);put("category",it.category);put("type",it.type);put("amount",it.amount);put("description",it.description);put("date",it.date)})}
        prefs.edit().putString("trades",t.toString()).putString("categories",c.toString()).putString("entries",e.toString()).apply()
    }

    private fun money(v:Double) = "₹" + String.format(Locale.US,"%,.2f",v)
    private fun today() = SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())

    // FIFO realized P&L: buy charges increase lot cost; sell charges reduce realized result.
    private fun realizedPnl():Double {
        var total=0.0
        trades.groupBy{it.stock.uppercase(Locale.US)}.values.forEach { list ->
            val lots=ArrayDeque<Pair<Double,Double>>() // qty, unit cost including buy charges
            list.sortedBy{it.date}.forEach { tr ->
                if(tr.type=="BUY" && tr.qty > 0.0) lots.addLast(Pair(tr.qty,tr.price + tr.charges/tr.qty))
                else {
                    var remain=tr.qty; var cost=0.0
                    while(remain>0 && lots.isNotEmpty()) {
                        val lot=lots.removeFirst(); val take=minOf(remain,lot.first); cost += take*lot.second
                        if(lot.first>take) lots.addFirst(Pair(lot.first-take,lot.second)); remain-=take
                    }
                    if(remain<=1e-9) total += tr.qty*tr.price - tr.charges - cost
                }
            }
        }
        return total
    }
    private fun transferredProfit() = entries.filter{it.type=="PROFIT"}.sumOf{it.amount}
    private fun availableProfit() = (realizedPnl()-transferredProfit()).coerceAtLeast(0.0)
    private fun balance(category:String) = entries.filter{it.category==category}.sumOf{if(it.type=="OUT") -it.amount else it.amount}

    private fun baseLayout(title:String): LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(CREAM); root.setPadding(16,16,16,8)
        val head=LinearLayout(this); head.gravity=Gravity.CENTER_VERTICAL
        val logo=ImageView(this); logo.setImageResource(com.biren.stockpnl.R.drawable.biren_logo); logo.scaleType=ImageView.ScaleType.CENTER_CROP
        head.addView(logo,LinearLayout.LayoutParams(64,64))
        val tv=TextView(this); tv.text=title; tv.textSize=24f; tv.setTextColor(GREEN); tv.setPadding(12,0,0,0); head.addView(tv,LinearLayout.LayoutParams(0,64,1f))
        root.addView(head)
        content=LinearLayout(this); content.orientation=LinearLayout.VERTICAL
        val scroll=ScrollView(this); scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this); nav.setBackgroundColor(GREEN)
        listOf("Home","Trades","Budget","Reports","Settings").forEach { label -> val b=Button(this); b.text=label; b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener{when(label){"Home"->showHome();"Trades"->showTrades();"Budget"->showBudget();"Reports"->showReports();else->showSettings()}}; nav.addView(b,LinearLayout.LayoutParams(0,56,1f)) }
        root.addView(nav); return root
    }
    private fun setScreen(title:String){setContentView(baseLayout(title))}
    private fun card(text:String, large:Boolean=false):TextView { val v=TextView(this); v.text=text; v.setTextColor(if(large)GREEN else Color.DKGRAY); v.textSize=if(large)22f else 16f; v.setPadding(16,16,16,16); val bg=GradientDrawable();bg.setColor(Color.WHITE);bg.cornerRadius=18f;v.background=bg; content.addView(v,LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(0,6,0,6)});return v }
    private fun button(text:String, action:()->Unit):Button { val b=Button(this); b.text=text;b.setOnClickListener{action()};content.addView(b,LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(0,4,0,4)});return b }
    private fun showHome(){setScreen("BiReN");card("NET P&L\n${money(realizedPnl())}",true);card("Available Profit\n${money(availableProfit())}");card("Budget Balance\n"+categories.joinToString("\n"){ "${it.name}: ${money(balance(it.name))}"},true);button("+ Trade"){showTradeDialog(null)};button("+ Budget OUT"){budgetDialog("OUT")};button("+ Budget IN"){budgetDialog("IN")}}

    private fun showTrades(){setScreen("Trades");button("+ Add Trade"){showTradeDialog(null)};if(trades.isEmpty())card("No trades yet\nAdd your first trade to start tracking P&L.") else trades.sortedByDescending{it.date}.forEach { t -> val row=card("${t.type}  ${t.stock}\n${t.qty} × ${money(t.price)}  •  ${t.date}\nCharges: ${money(t.charges)}");row.setOnClickListener{showTradeDialog(t)};button("Delete ${t.stock} ${t.date}"){confirm("Delete this trade?"){trades.removeIf{it.id==t.id};saveData();showTrades()}} }}

    private fun showBudget(){setScreen("Budget");val total=categories.sumOf{it.percent};card("Allocation: ${String.format(Locale.US,"%.1f",total)}%"+(if(abs(total-100)>0.001)"\nPercentages must total 100%." else ""),true);button("Allocate Available Profit Automatically"){allocateProfit()};button("+ IN"){budgetDialog("IN")};button("− OUT"){budgetDialog("OUT")};categories.forEach{c->card("${c.name}  •  ${c.percent}%\nBalance: ${money(balance(c.name))}",true);button("Edit ${c.name}"){categoryDialog(c)}};if(entries.isNotEmpty()){card("Recent Budget Entries",true);entries.sortedByDescending{it.date}.take(20).forEach{e->val sign=if(e.type=="OUT")"−" else "+";val row=card("$sign${money(e.amount)}  •  ${e.category}\n${e.description}\n${e.date}");row.setOnClickListener{budgetEditDialog(e)}}}}

    private fun showReports(){
        setScreen("Reports")
        card("Lifetime P&L\n${money(realizedPnl())}",true)
        card("Trades: ${trades.size}\nProfit Transferred: ${money(transferredProfit())}\nBudget Balance: ${money(categories.sumOf{balance(it.name)})}")
        button("This Month"){showPeriodReport(monthStart(),today())}
        button("This Year"){showPeriodReport(yearStart(),today())}
        button("Custom Period"){customPeriodDialog()}
        card("Monthly P&L",true)
        val months=trades.map{it.date.take(7)}.distinct().sortedDescending()
        if(months.isEmpty()) card("No trading data yet.") else months.take(12).forEach{m->val mp=periodPnl("$m-01","$m-31");card("$m\nNet P&L: ${money(mp)}")}
    }
    private fun monthStart():String = SimpleDateFormat("yyyy-MM-01",Locale.US).format(Date())
    private fun yearStart():String = SimpleDateFormat("yyyy-01-01",Locale.US).format(Date())
    private fun periodPnl(from:String,to:String):Double{
        var total=0.0
        trades.groupBy{it.stock.uppercase(Locale.US)}.values.forEach{list->
            val lots=ArrayDeque<Pair<Double,Double>>()
            list.sortedBy{it.date}.forEach{tr->
                if(tr.type=="BUY" && tr.qty > 0.0) lots.addLast(Pair(tr.qty,tr.price+tr.charges/tr.qty))
                else{
                    var remain=tr.qty;var cost=0.0
                    while(remain>0&&lots.isNotEmpty()){val lot=lots.removeFirst();val take=minOf(remain,lot.first);cost+=take*lot.second;if(lot.first>take)lots.addFirst(Pair(lot.first-take,lot.second));remain-=take}
                    if(remain<=1e-9&&tr.date>=from&&tr.date<=to) total+=tr.qty*tr.price-tr.charges-cost
                }
            }
        }
        return total
    }
    private fun showPeriodReport(from:String,to:String){
        val p=periodPnl(from,to)
        AlertDialog.Builder(this).setTitle("P&L Report").setMessage("$from to $to\n\nNet P&L: ${money(p)}\nTrades: ${trades.count{it.date>=from&&it.date<=to}}\nProfit allocated: ${money(entries.filter{it.type=="PROFIT"&&it.date>=from&&it.date<=to}.sumOf{it.amount})}").setPositiveButton("OK",null).show()
    }
    private fun customPeriodDialog(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
        val from=EditText(this);from.hint="From (YYYY-MM-DD)"
        val to=EditText(this);to.hint="To (YYYY-MM-DD)";to.setText(today())
        box.addView(from);box.addView(to)
        AlertDialog.Builder(this).setTitle("Custom Period").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Show"){_,_->if(from.text.isNotBlank())showPeriodReport(from.text.toString(),to.text.toString())}.show()
    }
    private fun showSettings(){setScreen("Settings");card("BiReN\nStock P&L & Budget Manager",true);button("Reset All Data"){confirm("Delete all app data?"){prefs.edit().clear().apply();trades.clear();entries.clear();categories.clear();categories.addAll(listOf(Category("Personal",40.0),Category("Savings",30.0),Category("Reinvestment",30.0)));saveData();showHome()}};card("Currency: INR (₹)\nLogo: BiReN Taurus green & gold")}

    private fun field(hint:String, value:String=""):EditText{val e=EditText(this);e.hint=hint;e.setText(value);e.inputType=2;return e}
    private fun showTradeDialog(existing:Trade?){val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("BUY","SELL"));if(existing!=null)type.setSelection(if(existing.type=="SELL")1 else 0);val stock=EditText(this);stock.hint="Stock";stock.setText(existing?.stock ?: "");val qty=field("Quantity",existing?.qty?.toString() ?: "");val price=field("Price",existing?.price?.toString() ?: "");val date=EditText(this);date.hint="Date (YYYY-MM-DD)";date.setText(existing?.date?:today());val charges=field("Charges",existing?.charges?.toString() ?: "0");listOf<View>(type,stock,qty,price,date,charges).forEach{box.addView(it)};box.addView(Button(this).apply{text="🧮 Calculator";setOnClickListener{calculator{r->price.setText(r)}}});AlertDialog.Builder(this).setTitle(if(existing==null)"Add Trade" else "Edit Trade").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->val q=qty.text.toString().toDoubleOrNull()?:0.0;val p=price.text.toString().toDoubleOrNull()?:0.0;if(stock.text.isBlank()||q<=0||p<=0){Toast.makeText(this,"Enter valid stock, quantity and price",Toast.LENGTH_SHORT).show();return@setPositiveButton};val t=Trade(existing?.id?:UUID.randomUUID().toString(),type.selectedItem.toString(),stock.text.toString().trim().uppercase(),q,p,date.text.toString().ifBlank{today()},charges.text.toString().toDoubleOrNull()?:0.0);if(existing==null)trades.add(t)else{val i=trades.indexOfFirst{it.id==existing.id};if(i>=0)trades[i]=t};saveData();showTrades()}.show()}

    private fun categoryDialog(c:Category){val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val n=EditText(this);n.setText(c.name);n.hint="Category name";val p=field("Percentage",c.percent.toString());box.addView(n);box.addView(p);AlertDialog.Builder(this).setTitle("Edit Category").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->val pct=p.text.toString().toDoubleOrNull()?:-1.0;if(pct<0){return@setPositiveButton};val old=c.name;val newName=n.text.toString().ifBlank{old};c.name=newName;c.percent=pct;if(old!=newName) entries.filter{it.category==old}.forEach{it.category=newName};saveData();showBudget()}.show()}
    private fun allocateProfit(){val total=categories.sumOf{it.percent};val p=availableProfit();if(abs(total-100)>0.001){Toast.makeText(this,"Allocation must total 100%",Toast.LENGTH_LONG).show();return};if(p<=0){Toast.makeText(this,"No available profit",Toast.LENGTH_SHORT).show();return};categories.forEach{val a=p*it.percent/100.0;entries.add(BudgetEntry(category=it.name,type="PROFIT",amount=a,description="Automatic profit allocation",date=today()))};saveData();showBudget()}
    private fun budgetDialog(type:String){if(categories.isEmpty())return;val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val cat=Spinner(this);cat.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,categories.map{it.name});val amount=field("Amount");val desc=EditText(this);desc.hint="Description";val date=EditText(this);date.hint="Date";date.setText(today());box.addView(cat);box.addView(amount);box.addView(desc);box.addView(date);box.addView(Button(this).apply{text="🧮 Calculator";setOnClickListener{calculator{r->amount.setText(r)}}});AlertDialog.Builder(this).setTitle("Budget $type").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->val a=amount.text.toString().toDoubleOrNull()?:0.0;if(a<=0)return@setPositiveButton;val cname=cat.selectedItem.toString();if(type=="OUT"&&a>balance(cname)&&!prefs.getBoolean("allowNegative",false)){Toast.makeText(this,"Expense exceeds available balance",Toast.LENGTH_LONG).show();return@setPositiveButton};entries.add(BudgetEntry(category=cname,type=type,amount=a,description=desc.text.toString().ifBlank{type},date=date.text.toString().ifBlank{today()}));saveData();showBudget()}.show()}
    private fun budgetEditDialog(e:BudgetEntry){val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val amount=field("Amount",e.amount.toString());val desc=EditText(this);desc.setText(e.description);val date=EditText(this);date.setText(e.date);box.addView(amount);box.addView(desc);box.addView(date);AlertDialog.Builder(this).setTitle("Edit ${e.type}").setView(box).setNegativeButton("Cancel",null).setNeutralButton("Delete"){_,_->entries.removeIf{it.id==e.id};saveData();showBudget()}.setPositiveButton("Save"){_,_->e.amount=amount.text.toString().toDoubleOrNull()?:e.amount;e.description=desc.text.toString();e.date=date.text.toString();saveData();showBudget()}.show()}

    private fun calculator(onResult:(String)->Unit){val input=EditText(this);input.hint="Example: 2500+1500*2";input.inputType=android.text.InputType.TYPE_CLASS_TEXT;AlertDialog.Builder(this).setTitle("Calculator").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Use Result"){_,_->val r=evaluate(input.text.toString());if(r!=null)onResult(String.format(Locale.US,"%.2f",r))}.show()}
    private fun evaluate(s:String):Double?{return try{val clean=s.replace("×","*").replace("÷","/").replace(" ","");if(!clean.matches(Regex("[0-9+*/.%-]+")))return null;val parts=clean.split("+");parts.sumOf{evalMul(it)}}catch(_:Exception){null}}
    private fun evalMul(s:String):Double{var x=0.0;var op='+';var token="";fun apply(){val v=token.toDouble();x=when(op){'+'->x+v;'-'->x-v;'*'->x*v;'/'->x/v;else->v};token=""};s.forEach{if(it in "-*/%"){apply();op=it}else token+=it};apply();return x}
    private fun confirm(msg:String, yes:()->Unit){AlertDialog.Builder(this).setMessage(msg).setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->yes()}.show()}
}
