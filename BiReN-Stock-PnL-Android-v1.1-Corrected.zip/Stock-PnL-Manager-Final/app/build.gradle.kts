plugins {
    id("com.android.application")
}

android {
    namespace = "com.biren.stockpnl"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.biren.stockpnl"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
